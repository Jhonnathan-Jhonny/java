/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wesleysafadao;

/**
 *
 * @author jhonnathan
 */
public class Safadometro {
    public int somatorioDoMes(int mes){
        int soma = 0;
        for(int i = 1; i <= mes; i++){
            soma += i;
        }

        return soma;
}

    public float Anjo(int dia, int mes, float ano, float safadeza){       
        float anjo;
        anjo = 100 - safadeza;

        System.out.println("Anjo: %.2f%%\n"+ anjo);
        return anjo;
    }
    public float Safadeza(int dia, int mes, float ano){
        float safadeza;
        safadeza = somatorioDoMes(mes) + (ano / 100) * (50 - dia);
        
        System.out.println("Safadeza: %.2f%%\n"+ safadeza);
        return safadeza;
    }
}
