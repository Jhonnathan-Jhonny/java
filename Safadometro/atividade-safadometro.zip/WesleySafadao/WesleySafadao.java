package com.mycompany.wesleysafadao;


public class WesleySafadao {;;
    public static void main(String[] args) {
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
        
    }
}
