package com.mycompany.projetocadastro;

public class ProjetoCadastro {

    public static void main(String[] args) {
        TelaCadastro tela = new TelaCadastro();
        tela.setResizable(false);
        tela.setLocationRelativeTo(tela);
        tela.setVisible(true);
        
        
//        Carro carro = new Carro();
//        
//        carro.setModelo("volksWagens");
//        carro.setModelo("Saveiro");
//        carro.setAno("2016");
//        carro.setCor("Branco");
//        carro.setMotor("1.6");
    }
}
