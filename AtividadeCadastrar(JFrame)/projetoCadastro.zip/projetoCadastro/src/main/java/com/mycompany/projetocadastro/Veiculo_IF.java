package com.mycompany.projetocadastro;

public interface Veiculo_IF {
    public void cadastrarVeiculo();
}
