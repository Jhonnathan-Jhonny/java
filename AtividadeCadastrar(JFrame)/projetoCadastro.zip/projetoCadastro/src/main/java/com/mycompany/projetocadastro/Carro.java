package com.mycompany.projetocadastro;

public class Carro extends Veiculo{
    private String motor;

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    } 
}
